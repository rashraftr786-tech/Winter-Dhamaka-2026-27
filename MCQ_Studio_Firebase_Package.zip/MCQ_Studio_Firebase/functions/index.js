const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore, FieldValue} = require("firebase-admin/firestore");
const {getAuth} = require("firebase-admin/auth");
initializeApp();
const db = getFirestore();

exports.submitQuiz = onCall({region: "us-central1", enforceAppCheck: false}, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Please sign in first.");
  const uid = request.auth.uid;
  const profileSnap = await db.collection("users").doc(uid).get();
  if (!profileSnap.exists) throw new HttpsError("permission-denied", "Student profile not found.");
  const p = profileSnap.data();
  if (p.role !== "student" || p.active !== true) throw new HttpsError("permission-denied", "Only active student accounts may submit quizzes.");

  const {questionIds, answers, subject, elapsedSeconds} = request.data || {};
  if (!Array.isArray(questionIds) || !Array.isArray(answers) || questionIds.length < 1 ||
      questionIds.length > 50 || questionIds.length !== answers.length) {
    throw new HttpsError("invalid-argument", "Invalid quiz submission.");
  }
  if (new Set(questionIds).size !== questionIds.length) throw new HttpsError("invalid-argument", "Duplicate question IDs are not allowed.");

  let correct = 0;
  for (let i = 0; i < questionIds.length; i++) {
    const qSnap = await db.collection("questions").doc(String(questionIds[i])).get();
    if (!qSnap.exists) throw new HttpsError("failed-precondition", "A quiz question no longer exists.");
    const q = qSnap.data();
    if (q.stage !== p.stage || q.grade !== p.grade || q.subject !== subject) {
      throw new HttpsError("permission-denied", "A question is outside your assigned grade or domain.");
    }
    const keySnap = await db.collection("answerKeys").doc(String(questionIds[i])).get();
    if (!keySnap.exists) throw new HttpsError("failed-precondition", "Answer key unavailable.");
    const a = answers[i];
    if (Number.isInteger(a) && a >= 0 && a < q.options.length && a === keySnap.data().answerIndex) correct++;
  }

  const total = questionIds.length;
  const percentage = Math.round((correct / total) * 100);
  const pointsAwarded = correct * 10 + 5 + (percentage >= 80 ? 10 : 0) + (percentage === 100 ? 20 : 0);
  const resultRef = db.collection("results").doc();
  const userRef = db.collection("users").doc(uid);
  const newTotal = await db.runTransaction(async (tx) => {
    const fresh = await tx.get(userRef);
    if (!fresh.exists || fresh.data().role !== "student" || fresh.data().active !== true) {
      throw new HttpsError("permission-denied", "Student account is inactive.");
    }
    const oldPoints = Number(fresh.data().points || 0);
    const oldCount = Number(fresh.data().quizCount || 0);
    const updatedTotal = oldPoints + pointsAwarded;
    tx.update(userRef, {points: updatedTotal, quizCount: oldCount + 1, updatedAt: FieldValue.serverTimestamp()});
    tx.set(resultRef, {
      studentId: uid, studentName: p.name || "", roll: p.roll || "",
      stage: p.stage, grade: p.grade, subject: String(subject || ""),
      correct, total, percentage, pointsAwarded, totalPoints: updatedTotal,
      elapsedSeconds: Math.max(0, Math.min(7200, Number(elapsedSeconds || 0))),
      createdAt: FieldValue.serverTimestamp()
    });
    return updatedTotal;
  });
  return {correct, total, percentage, pointsAwarded, totalPoints: newTotal};
});