# MCQ Studio — Firebase Edition

This package upgrades the supplied MCQ Studio into an Admin + Student portal with stage/grade assignment, cloud question bank, cloud results and trusted points calculation.

## Included files
- `index.html` — application interface. Replace the Firebase config placeholders before deployment.
- `firestore.rules` — access rules. Students cannot read answer keys or write their own results/points.
- `functions/index.js` — trusted server-side scoring and points award.
- `functions/package.json` — Cloud Functions dependencies.

## 1. Create Firebase project
1. Open https://console.firebase.google.com/ and create a project.
2. Add a Web App and copy its Firebase configuration.
3. In `index.html`, replace all values in `firebaseConfig`:
   `PASTE_API_KEY`, `PASTE_PROJECT_ID`, `PASTE_MESSAGING_SENDER_ID`, `PASTE_APP_ID`.
4. Enable **Authentication → Sign-in method → Email/Password**.
5. Create a **Cloud Firestore** database (production mode).
6. Enable billing / Blaze plan if required for deploying Cloud Functions.

## 2. Create the first administrator
1. In Firebase Console → Authentication → Users → Add user, create the administrator email/password.
2. Copy the administrator's UID.
3. In Firestore, create collection `users`, document ID exactly equal to that UID.
4. Add these fields:
   - `name` (string): Administrator
   - `email` (string): the admin email
   - `role` (string): `admin`
   - `active` (boolean): `true`
5. Do not create an admin account through the student creation form.

## 3. Deploy Firestore security rules
Use Firebase Console → Firestore Database → Rules and publish the complete contents of `firestore.rules`.

## 4. Deploy trusted scoring function
Install Node.js 20 and Firebase CLI, sign in, then from this folder run:

```bash
npm install -g firebase-tools
firebase login
firebase init functions
```

Choose the existing project, JavaScript, Node 20. Copy this package's `functions/index.js` and `functions/package.json` into the generated `functions` directory (replace existing files), then:

```bash
cd functions
npm install
cd ..
firebase deploy --only functions:submitQuiz
```

If Firebase asks for a billing upgrade, attach a billing account to the project. Keep the function region `us-central1` consistent with `FUNCTIONS_REGION` in the HTML.

## 5. Host the HTML
Deploy `index.html` using Firebase Hosting, or host it on another HTTPS static host. For Firebase Hosting:

```bash
firebase init hosting
```

Set the public directory to the folder containing `index.html`, then:

```bash
firebase deploy --only hosting
```

## 6. Add students
Sign in as admin → Students. Enter each student's name, roll/admission number, email/login ID, temporary password, stage and grade. The system creates the Firebase Authentication account and matching Firestore profile. Share the login credentials privately and ask students to change their password after first login (password-change UI can be added in a later iteration).

## 7. Import questions
Admin → Import. Select the stage and grade, then upload an Excel/CSV workbook. The import template includes:
`Stage, Grade, Domain/Subject, Question, Option A, Option B, Option C, Option D, Correct Answer, Explanation, Difficulty`.

The selected Stage and Grade are used as defaults if those columns are absent. Domain/Subject must match a domain configured for that stage. Correct Answer accepts A-D, 1-4, or exact option text.

## Grade mapping in this build
- Foundational: Pre-Primary 3, Pre-Primary 2, Balvatika, Grade 1, Grade 2
- Preparatory: Grade 3, Grade 4, Grade 5
- Middle: Grade 6, Grade 7, Grade 8

The student is only shown questions where both stage and grade match the student's profile.

## Points policy
- Correct answer: +10
- Completing a quiz: +5
- Accuracy >= 80%: +10
- Perfect score: +20

Points are awarded by the Cloud Function, not calculated in the browser. Achievement labels: Beginner (0–99), Learner (100–249), Achiever (250–499), Champion (500–999), Master Learner (1000+).

## Important limitations / operational safeguards
- This is a deployable first version, not a full school SIS. It intentionally does not include student self-registration.
- Admin accounts must be provisioned manually in Firebase Console. Never expose service-account keys in the HTML.
- The app's Admin role is stored in Firestore. Only trusted admins should have write access to user profiles and question content. Protect administrator Google/Firebase accounts with strong passwords and MFA.
- The scoring function validates each question's stage, grade and subject and reads answer keys server-side. The Firestore rules deny student reads of `answerKeys` and deny direct writes to `results`.
- For production use, enable Firebase App Check, consider rate limiting / quiz attempt controls, and add a password reset/change workflow. The function currently limits a quiz to 50 questions.
- If Firestore asks you to create a composite index for a query, follow the index-creation link in the Firebase error message.
- The question list is limited to the first 500 records in the admin inventory view; the import itself can process larger files in batches.

## Existing Excel question file compatibility
The original Stage / Domain / Question / Option A-D / Correct Answer / Explanation / Difficulty columns are retained. Grade can be assigned through the Admin import selector if your current workbook does not yet have a Grade column.
